# Messi Fan Stats — Android / Google Play

هذه نسخة Android Studio من تطبيق Messi الحالي.

## معلومات المشروع
- اسم التطبيق: Messi Fan Stats
- Package ID: `com.elia.messifan`
- minSdk: 26
- targetSdk / compileSdk: 36
- Version: 1.0.0 (versionCode 1)
- الصلاحيات: INTERNET فقط
- رابط عودة Mollie: `messifan://payment-return`

## فتح المشروع
1. ثبّت أحدث Android Studio.
2. اختر **Open** وحدد مجلد `messi-android-studio`.
3. استخدم JDK 17 في Gradle Settings.
4. ثبّت Android SDK Platform 36 وBuild Tools إذا طلب Android Studio ذلك.
5. انتظر Gradle Sync.

## تجربة التطبيق على الهاتف
- فعّل Developer options وUSB debugging في هاتف Android.
- وصّل الهاتف بالكمبيوتر.
- اضغط Run في Android Studio.

## إنشاء AAB لـ Google Play
من Android Studio:
**Build → Generate Signed App Bundle or APK → Android App Bundle**
ثم أنشئ Keystore جديدًا واحفظه في مكان آمن جدًا.

لا تفقد ملف الـKeystore أو كلمة المرور؛ ستحتاجهما لتحديث التطبيق لاحقًا.

## مهم قبل النشر
الدفع الحالي هو Mollie. إذا نُشر التطبيق على Google Play وهو يبيع تفعيلًا رقميًا داخل التطبيق، يجب التأكد من التوافق مع قواعد Google Play Billing/Alternative Billing في المنطقة التي ستوزع فيها التطبيق.

## بناء AAB عبر GitHub بدون تثبيت Android Studio
المشروع يحتوي على Workflow جاهز في:
`.github/workflows/android-aab.yml`

بعد رفع المشروع إلى GitHub:
1. افتح تبويب **Actions**.
2. اختر **Build Android AAB**.
3. اضغط **Run workflow**.
4. بعد اكتمال البناء، حمّل artifact باسم `messi-fan-stats-aab`.

هذا الـAAB سيكون مناسبًا للاختبار، لكن قبل رفع نسخة إنتاج إلى Google Play أنشئ Upload Keystore خاصًا بك ووقّع نسخة الإصدار.
